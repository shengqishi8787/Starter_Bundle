History
-------

   The original concept was developed and implemented by
   Manos Renieris at Brown University: 
   http://www.cs.brown.edu/~er/software/
